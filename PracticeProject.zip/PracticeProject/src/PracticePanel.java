// Panels that will utilize the individual panels of of canvas objects 

public class PracticePanel {
	
	static PracticeCanvas pCanvas[] = new PracticeCanvas[100]; 
	
	public PracticePanel() { 
		
	}

}
